function createArtwork(imagePath, position) {
    const loader = new THREE.TextureLoader();
    const texture = loader.load(imagePath);
    const planeGeometry = new THREE.PlaneGeometry(10, 10);
    const planeMaterial = new THREE.MeshBasicMaterial({ map: texture });
    const plane = new THREE.Mesh(planeGeometry, planeMaterial);
    plane.position.set(...position);
    return plane;
  }
  
  const artwork1 = createArtwork('path/to/art1.jpg', [0, 5, -49.5]);
  scene.add(artwork1);
  