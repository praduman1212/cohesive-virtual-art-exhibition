function createGallery() {
    const gallery = new THREE.Group();
  
    // Floor
    const floorGeometry = new THREE.BoxGeometry(100, 1, 100);
    const floorMaterial = new THREE.MeshPhongMaterial({ color: 0x8B4513 });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.position.y = -1; // Lower the floor slightly
    gallery.add(floor);
  
    // Walls
    const wallGeometry = new THREE.BoxGeometry(100, 10, 1);
    const wallMaterial = new THREE.MeshPhongMaterial({ color: 0xffffff });
    const wall1 = new THREE.Mesh(wallGeometry, wallMaterial);
    wall1.position.set(0, 5, -50);
    gallery.add(wall1);
  
    // Additional walls...
  
    scene.add(gallery);
  }
  
  createGallery();
  