function addAudio() {
    const listener = new THREE.AudioListener();
    camera.add(listener);
  
    const backgroundMusic = new THREE.Audio(listener);
    const audioLoader = new THREE.AudioLoader();
    audioLoader.load('path/to/background-music.mp3', (buffer) => {
      backgroundMusic.setBuffer(buffer);
      backgroundMusic.setLoop(true);
      backgroundMusic.setVolume(0.5);
      backgroundMusic.play();
    });
  
    const sound = new THREE.PositionalAudio(listener);
    audioLoader.load('path/to/narration.mp3', (buffer) => {
      sound.setBuffer(buffer);
      sound.setRefDistance(20);
      sound.play();
    });
    artwork1.add(sound);
  }
  
  addAudio();
  